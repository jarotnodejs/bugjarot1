global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6285768376295']
global.botname = 'X-VALDEZ '
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "X-VALDEZ OFC"
global.sticker2 = "💋"