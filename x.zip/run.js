// Base By Valdez Official 
const _0x43c3fb = _0x2fbe;
(function (_0x4db406, _0x2fbb8f) {
    const _0x232a4f = _0x2fbe, _0x208983 = _0x4db406();
    while (!![]) {
        try {
            const _0x5c9090 = -parseInt(_0x232a4f(0x214)) / (-0x19ec + 0x181c + -0xf * -0x1f) + parseInt(_0x232a4f(0x289)) / (0x1 * 0x166d + -0x31e * 0xa + -0x1b * -0x53) * (parseInt(_0x232a4f(0x263)) / (-0x1 * 0x26ed + 0x1 * 0x148d + -0x621 * -0x3)) + parseInt(_0x232a4f(0x21b)) / (-0x2c * 0xac + -0x1ca4 + -0xa2 * -0x5c) * (parseInt(_0x232a4f(0x204)) / (0x2 * 0xb1e + -0x1 * -0xee6 + -0x251d)) + -parseInt(_0x232a4f(0x27a)) / (-0x8c5 * 0x3 + 0x13e3 + 0x14a * 0x5) + parseInt(_0x232a4f(0x248)) / (0x1 * -0xacc + -0x1848 + 0x231b) * (parseInt(_0x232a4f(0x2a0)) / (-0xafb + 0x2143 + 0x40 * -0x59)) + parseInt(_0x232a4f(0x1eb)) / (0xb5a + -0x14d0 + 0x97f) * (-parseInt(_0x232a4f(0x21e)) / (-0x298 + -0xa8d * 0x1 + -0xd2f * -0x1)) + parseInt(_0x232a4f(0x286)) / (0x2 * -0x212 + 0x7ee + 0x1 * -0x3bf) * (-parseInt(_0x232a4f(0x275)) / (-0x2a1 + -0x13 * 0x10f + -0x16ca * -0x1));
            if (_0x5c9090 === _0x2fbb8f)
                break;
            else
                _0x208983['push'](_0x208983['shift']());
        } catch (_0x434e7a) {
            _0x208983['push'](_0x208983['shift']());
        }
    }
}(_0x5dfe, -0x15a52 * -0xf + -0x19f90 * 0xa + 0x8061d), require(_0x43c3fb(0x205)));
const {
        default: rxhlConnect,
        makeWASocket,
        useMultiFileAuthState,
        DisconnectReason,
        fetchLatestBaileysVersion,
        generateForwardMessageContent,
        prepareWAMessageMedia,
        generateWAMessageFromContent,
        generateMessageID,
        downloadContentFromMessage,
        makeInMemoryStore,
        jidDecode,
        proto,
        getAggregateVotesInPollMessage
    } = global[_0x43c3fb(0x250)], pino = require(_0x43c3fb(0x24c)), {Boom} = require(_0x43c3fb(0x212)), fs = require('fs'), FileType = require(_0x43c3fb(0x1f6)), readline = require(_0x43c3fb(0x1f8)), PhoneNumber = require(_0x43c3fb(0x247) + _0x43c3fb(0x20f)), path = require(_0x43c3fb(0x276)), NodeCache = require(_0x43c3fb(0x235)), {smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep} = require(_0x43c3fb(0x265) + _0x43c3fb(0x21f)), {imageToWebp, videoToWebp, writeExifImg, writeExifVid} = require(_0x43c3fb(0x242)), store = makeInMemoryStore({
        'logger': pino()[_0x43c3fb(0x22d)]({
            'level': _0x43c3fb(0x277),
            'stream': _0x43c3fb(0x270)
        })
    }), usePairingCode = !![], question = _0x29e5de => {
        const _0x3be2a6 = _0x43c3fb, _0x159dfc = readline[_0x3be2a6(0x295) + _0x3be2a6(0x26d)]({
                'input': process[_0x3be2a6(0x25c)],
                'output': process[_0x3be2a6(0x241)]
            });
        return new Promise(_0x3c702a => {
            const _0x1ac0a5 = _0x3be2a6;
            _0x159dfc[_0x1ac0a5(0x255)](_0x29e5de, _0x3c702a);
        });
    };
async function connectToWhatsApp() {
    const _0x9a5a0 = _0x43c3fb, _0x576572 = {
            'FcmJx': _0x9a5a0(0x21d) + _0x9a5a0(0x230) + _0x9a5a0(0x221),
            'YnNCF': function (_0x50f9e7, _0x172556) {
                return _0x50f9e7(_0x172556);
            },
            'svlmW': function (_0x3ff234, _0x562569) {
                return _0x3ff234 + _0x562569;
            },
            'iAHnT': function (_0x8793ab, _0x29bbef) {
                return _0x8793ab + _0x29bbef;
            },
            'NgEzJ': _0x9a5a0(0x27b),
            'Xghgl': function (_0x26d15f, _0x33c9e7) {
                return _0x26d15f(_0x33c9e7);
            },
            'mujpZ': function (_0x2527ce, _0x3132ad) {
                return _0x2527ce === _0x3132ad;
            },
            'bVttH': _0x9a5a0(0x22a),
            'tVGLC': _0x9a5a0(0x28a) + _0x9a5a0(0x223) + _0x9a5a0(0x225),
            'IVZXT': _0x9a5a0(0x1f3),
            'fTHBh': function (_0xb9159c, _0x5c6161) {
                return _0xb9159c + _0x5c6161;
            },
            'jMSUT': function (_0x2bce8c, _0x5d90a8) {
                return _0x2bce8c + _0x5d90a8;
            },
            'HgWuG': _0x9a5a0(0x28d),
            'RdhrX': function (_0x5daa07, _0x1aa7df) {
                return _0x5daa07 * _0x1aa7df;
            },
            'EmpBq': function (_0x1faa74, _0xd5d523) {
                return _0x1faa74 && _0xd5d523;
            },
            'XATpU': function (_0x4d1bef, _0x2dbb2a, _0x3c1d98) {
                return _0x4d1bef(_0x2dbb2a, _0x3c1d98);
            },
            'AewaO': function (_0xc78d06, _0x5be131) {
                return _0xc78d06(_0x5be131);
            },
            'OcAdB': function (_0x1419d2, _0x5d9cff, _0xa7aa61) {
                return _0x1419d2(_0x5d9cff, _0xa7aa61);
            },
            'pSWwc': function (_0x36c78d, _0x123c2f, _0x1ab175) {
                return _0x36c78d(_0x123c2f, _0x1ab175);
            },
            'BQczD': function (_0x2bf656, _0x17fac5) {
                return _0x2bf656 + _0x17fac5;
            },
            'NSPjZ': _0x9a5a0(0x236) + _0x9a5a0(0x23d),
            'GgCrw': function (_0x3d7512, _0x106063) {
                return _0x3d7512 === _0x106063;
            },
            'MERSV': _0x9a5a0(0x249) + _0x9a5a0(0x27e),
            'GqqaD': _0x9a5a0(0x24d),
            'MfJiG': function (_0x4ca3cc, _0x25ab5c) {
                return _0x4ca3cc === _0x25ab5c;
            },
            'RMohD': _0x9a5a0(0x280) + _0x9a5a0(0x279),
            'BsTlQ': _0x9a5a0(0x22f),
            'iPQND': _0x9a5a0(0x22e),
            'kjrXK': function (_0x380e30, _0x4cdb39, _0x121e0a, _0x2ef3e7) {
                return _0x380e30(_0x4cdb39, _0x121e0a, _0x2ef3e7);
            },
            'quLMh': _0x9a5a0(0x256),
            'lUukP': function (_0x156f4c, _0xdc5509) {
                return _0x156f4c !== _0xdc5509;
            },
            'QKCrg': function (_0x82beb) {
                return _0x82beb();
            },
            'tgVQn': _0x9a5a0(0x215),
            'VYthf': _0x9a5a0(0x252) + _0x9a5a0(0x226),
            'VohAZ': _0x9a5a0(0x27c),
            'fjzwD': function (_0x31c644, _0x3ad36b) {
                return _0x31c644(_0x3ad36b);
            },
            'EQRmc': function (_0x6e1716, _0x35c633) {
                return _0x6e1716(_0x35c633);
            },
            'RLgbT': _0x9a5a0(0x277),
            'MYlRU': _0x9a5a0(0x22c),
            'yIpWZ': _0x9a5a0(0x1f0),
            'WNWdI': _0x9a5a0(0x284) + _0x9a5a0(0x1f7),
            'upVit': function (_0x37486b, _0x124ec3) {
                return _0x37486b(_0x124ec3);
            },
            'qxSpH': _0x9a5a0(0x20a) + _0x9a5a0(0x23a) + _0x9a5a0(0x23f) + _0x9a5a0(0x23c) + _0x9a5a0(0x20b) + _0x9a5a0(0x20e) + _0x9a5a0(0x1f9) + _0x9a5a0(0x1ec) + _0x9a5a0(0x211) + _0x9a5a0(0x1fb),
            'BbLsn': _0x9a5a0(0x278),
            'BOuoY': _0x9a5a0(0x202) + _0x9a5a0(0x287),
            'VppfG': _0x9a5a0(0x26e) + _0x9a5a0(0x219),
            'sJLZt': _0x9a5a0(0x288) + 'te'
        }, {
            state: _0x5726a6,
            saveCreds: _0x471517
        } = await _0x576572[_0x9a5a0(0x29c)](useMultiFileAuthState, _0x576572[_0x9a5a0(0x1fa)]), {
            version: _0x442c47,
            isLatest: _0x324a16
        } = await _0x576572[_0x9a5a0(0x21c)](fetchLatestBaileysVersion), _0x42e0b2 = new NodeCache(), _0x4a9a40 = _0x576572[_0x9a5a0(0x27f)](makeWASocket, {
            'isLatest': _0x324a16,
            'keepAliveIntervalMs': 0xc350,
            'printQRInTerminal': !usePairingCode,
            'logger': _0x576572[_0x9a5a0(0x27d)](pino, { 'level': _0x576572[_0x9a5a0(0x229)] }),
            'auth': _0x5726a6,
            'browser': [
                _0x576572[_0x9a5a0(0x28e)],
                _0x576572[_0x9a5a0(0x262)],
                _0x576572[_0x9a5a0(0x26b)]
            ],
            'version': [
                0x1962 + 0x4d8 + 0xf1c * -0x2,
                0x2051 + -0x1 * 0x29 + -0xfd * 0x17,
                -0x6a * 0x2 + 0x20a8 + -0x1 * 0x1fd3
            ],
            'generateHighQualityLinkPreview': !![],
            'resolveMsgBuffer': _0x42e0b2
        });
    if (usePairingCode && !_0x4a9a40[_0x9a5a0(0x28c)][_0x9a5a0(0x233)][_0x9a5a0(0x1ff)]) {
        const _0x7c00b3 = await _0x576572[_0x9a5a0(0x1ed)](question, _0x576572[_0x9a5a0(0x217)]), _0x208a70 = await _0x4a9a40[_0x9a5a0(0x201) + _0x9a5a0(0x269)](_0x7c00b3[_0x9a5a0(0x266)]());
        console[_0x9a5a0(0x222)](_0x9a5a0(0x1f5) + _0x9a5a0(0x244) + _0x208a70);
    }
    store[_0x9a5a0(0x25a)](_0x4a9a40['ev']), _0x4a9a40['ev']['on'](_0x576572[_0x9a5a0(0x23b)], async _0x555800 => {
        const _0x1a1349 = _0x9a5a0;
        console[_0x1a1349(0x222)](_0x576572[_0x1a1349(0x213)]);
    }), _0x4a9a40[_0x9a5a0(0x260)] = _0x51b543 => {
        const _0x41c156 = _0x9a5a0;
        if (!_0x51b543)
            return _0x51b543;
        if (/:\d+@/gi[_0x41c156(0x227)](_0x51b543)) {
            let _0x17aed3 = _0x576572[_0x41c156(0x29f)](jidDecode, _0x51b543) || {};
            return _0x17aed3[_0x41c156(0x207)] && _0x17aed3[_0x41c156(0x261)] && _0x576572[_0x41c156(0x283)](_0x576572[_0x41c156(0x267)](_0x17aed3[_0x41c156(0x207)], '@'), _0x17aed3[_0x41c156(0x261)]) || _0x51b543;
        } else
            return _0x51b543;
    }, _0x4a9a40[_0x9a5a0(0x258)] = async (_0x13e361, _0x3062e9) => {
        const _0x416281 = _0x9a5a0;
        let _0x13644c, _0x8d6d1d = Buffer[_0x416281(0x290)](_0x13e361) ? _0x13e361 : /^data:.*?\/.*?;base64,/i[_0x416281(0x227)](_0x13e361) ? Buffer[_0x416281(0x24e)](_0x13e361[_0x416281(0x25e)]`,`[0xb9d + 0x144 * 0x7 + -0x1478], _0x576572[_0x416281(0x232)]) : /^https?:\/\//[_0x416281(0x227)](_0x13e361) ? await (_0x13644c = await _0x576572[_0x416281(0x21a)](getBuffer, _0x13e361)) : fs[_0x416281(0x294)](_0x13e361) ? (filename = _0x13e361, fs[_0x416281(0x28b) + 'nc'](_0x13e361)) : _0x576572[_0x416281(0x1fc)](typeof _0x13e361, _0x576572[_0x416281(0x25b)]) ? _0x13e361 : Buffer[_0x416281(0x292)](0x25ed + 0x41 * 0xa + 0x2877 * -0x1), _0x5e0a4e = await FileType[_0x416281(0x296)](_0x8d6d1d) || {
                'mime': _0x576572[_0x416281(0x234)],
                'ext': _0x576572[_0x416281(0x26c)]
            };
        filename = path[_0x416281(0x253)](__filename, _0x576572[_0x416281(0x22b)](_0x576572[_0x416281(0x281)](_0x576572[_0x416281(0x281)](_0x576572[_0x416281(0x293)], _0x576572[_0x416281(0x24b)](new Date(), -0x3 * 0x11d + 0x26e3 + -0x238b)), '.'), _0x5e0a4e[_0x416281(0x26a)]));
        if (_0x576572[_0x416281(0x200)](_0x8d6d1d, _0x3062e9))
            fs[_0x416281(0x1f1)][_0x416281(0x29a)](filename, _0x8d6d1d);
        return {
            'res': _0x13644c,
            'filename': filename,
            'size': await _0x576572[_0x416281(0x29f)](getSizeMedia, _0x8d6d1d),
            ..._0x5e0a4e,
            'data': _0x8d6d1d
        };
    }, _0x4a9a40[_0x9a5a0(0x1fe) + _0x9a5a0(0x240)] = async _0x3a27e5 => {
        const _0x4330de = _0x9a5a0;
        let _0x576f64 = (_0x3a27e5[_0x4330de(0x251)] || _0x3a27e5)[_0x4330de(0x245)] || '', _0x13c6c1 = _0x3a27e5[_0x4330de(0x1ee)] ? _0x3a27e5[_0x4330de(0x1ee)][_0x4330de(0x2a1)](/Message/gi, '') : _0x576f64[_0x4330de(0x25e)]('/')[0x1 * 0x1ff9 + 0x1 * 0x1273 + 0x734 * -0x7];
        const _0xdd1dc3 = await _0x576572[_0x4330de(0x1f4)](downloadContentFromMessage, _0x3a27e5, _0x13c6c1);
        let _0xd9eec4 = Buffer[_0x4330de(0x24e)]([]);
        for await (const _0x5c3206 of _0xdd1dc3) {
            _0xd9eec4 = Buffer[_0x4330de(0x29b)]([
                _0xd9eec4,
                _0x5c3206
            ]);
        }
        return _0xd9eec4;
    }, _0x4a9a40[_0x9a5a0(0x268)] = (_0x4d2ebf, _0x17f47f, _0x2d343f = '', _0x2e36da) => _0x4a9a40[_0x9a5a0(0x238) + 'e'](_0x4d2ebf, {
        'text': _0x17f47f,
        ..._0x2e36da
    }, { 'quoted': _0x2d343f }), _0x4a9a40[_0x9a5a0(0x272) + _0x9a5a0(0x298)] = async (_0x3abef0, _0x42773d, _0x2704bc, _0x470b1b = {}) => {
        const _0x18ff3f = _0x9a5a0;
        let _0x53db15 = Buffer[_0x18ff3f(0x290)](_0x42773d) ? _0x42773d : /^data:.*?\/.*?;base64,/i[_0x18ff3f(0x227)](_0x42773d) ? Buffer[_0x18ff3f(0x24e)](_0x42773d[_0x18ff3f(0x25e)]`,`[0xb + -0xf05 + 0xefb], _0x576572[_0x18ff3f(0x232)]) : /^https?:\/\//[_0x18ff3f(0x227)](_0x42773d) ? await await _0x576572[_0x18ff3f(0x21a)](getBuffer, _0x42773d) : fs[_0x18ff3f(0x294)](_0x42773d) ? fs[_0x18ff3f(0x28b) + 'nc'](_0x42773d) : Buffer[_0x18ff3f(0x292)](-0x1 * -0xfb + -0x14c6 * 0x1 + 0x13cb), _0x51c5de;
        return _0x470b1b && (_0x470b1b[_0x18ff3f(0x1fd)] || _0x470b1b[_0x18ff3f(0x24a)]) ? _0x51c5de = await _0x576572[_0x18ff3f(0x1f4)](writeExifImg, _0x53db15, _0x470b1b) : _0x51c5de = await _0x576572[_0x18ff3f(0x21a)](imageToWebp, _0x53db15), await _0x4a9a40[_0x18ff3f(0x238) + 'e'](_0x3abef0, {
            'sticker': { 'url': _0x51c5de },
            ..._0x470b1b
        }, { 'quoted': _0x2704bc }), _0x51c5de;
    }, _0x4a9a40[_0x9a5a0(0x299) + _0x9a5a0(0x298)] = async (_0x476ac5, _0x4f252f, _0x57c569, _0x4b19fb = {}) => {
        const _0x24a194 = _0x9a5a0;
        let _0x577e24 = Buffer[_0x24a194(0x290)](_0x4f252f) ? _0x4f252f : /^data:.*?\/.*?;base64,/i[_0x24a194(0x227)](_0x4f252f) ? Buffer[_0x24a194(0x24e)](_0x4f252f[_0x24a194(0x25e)]`,`[-0x1 * 0x2a1 + -0x1eb4 + 0x2156], _0x576572[_0x24a194(0x232)]) : /^https?:\/\//[_0x24a194(0x227)](_0x4f252f) ? await await _0x576572[_0x24a194(0x29c)](getBuffer, _0x4f252f) : fs[_0x24a194(0x294)](_0x4f252f) ? fs[_0x24a194(0x28b) + 'nc'](_0x4f252f) : Buffer[_0x24a194(0x292)](-0x19c5 + -0xde * -0x2b + -0x3d7 * 0x3), _0x2e6ae2;
        return _0x4b19fb && (_0x4b19fb[_0x24a194(0x1fd)] || _0x4b19fb[_0x24a194(0x24a)]) ? _0x2e6ae2 = await _0x576572[_0x24a194(0x297)](writeExifVid, _0x577e24, _0x4b19fb) : _0x2e6ae2 = await _0x576572[_0x24a194(0x29f)](videoToWebp, _0x577e24), await _0x4a9a40[_0x24a194(0x238) + 'e'](_0x476ac5, {
            'sticker': { 'url': _0x2e6ae2 },
            ..._0x4b19fb
        }, { 'quoted': _0x57c569 }), _0x2e6ae2;
    }, _0x4a9a40[_0x9a5a0(0x1f2) + _0x9a5a0(0x239) + _0x9a5a0(0x231)] = async (_0x5cc487, _0x164dd3, _0x4fd7c7 = !![]) => {
        const _0x51f5d1 = _0x9a5a0;
        let _0x8eda38 = _0x5cc487[_0x51f5d1(0x251)] ? _0x5cc487[_0x51f5d1(0x251)] : _0x5cc487, _0x177a67 = (_0x5cc487[_0x51f5d1(0x251)] || _0x5cc487)[_0x51f5d1(0x245)] || '', _0x33820d = _0x5cc487[_0x51f5d1(0x1ee)] ? _0x5cc487[_0x51f5d1(0x1ee)][_0x51f5d1(0x2a1)](/Message/gi, '') : _0x177a67[_0x51f5d1(0x25e)]('/')[-0x985 * 0x1 + -0x803 + 0x1188];
        const _0x2f54d5 = await _0x576572[_0x51f5d1(0x243)](downloadContentFromMessage, _0x8eda38, _0x33820d);
        let _0x2f07c2 = Buffer[_0x51f5d1(0x24e)]([]);
        for await (const _0x13e283 of _0x2f54d5) {
            _0x2f07c2 = Buffer[_0x51f5d1(0x29b)]([
                _0x2f07c2,
                _0x13e283
            ]);
        }
        let _0x1173f7 = await FileType[_0x51f5d1(0x296)](_0x2f07c2);
        return trueFileName = _0x4fd7c7 ? _0x576572[_0x51f5d1(0x210)](_0x576572[_0x51f5d1(0x281)](_0x164dd3, '.'), _0x1173f7[_0x51f5d1(0x26a)]) : _0x164dd3, await fs[_0x51f5d1(0x257) + _0x51f5d1(0x25f)](trueFileName, _0x2f07c2), trueFileName;
    }, _0x4a9a40['ev']['on'](_0x576572[_0x9a5a0(0x23e)], async _0x46b5e5 => {
        const _0x4a7c7a = _0x9a5a0;
        try {
            const _0x46d6d1 = _0x576572[_0x4a7c7a(0x218)][_0x4a7c7a(0x25e)]('|');
            let _0x2fe386 = 0x208c + -0x26 * -0x13 + -0x235e;
            while (!![]) {
                switch (_0x46d6d1[_0x2fe386++]) {
                case '0':
                    if (mek[_0x4a7c7a(0x208)] && _0x576572[_0x4a7c7a(0x29d)](mek[_0x4a7c7a(0x208)][_0x4a7c7a(0x259)], _0x576572[_0x4a7c7a(0x237)]))
                        return;
                    continue;
                case '1':
                    if (!mek[_0x4a7c7a(0x228)])
                        return;
                    continue;
                case '2':
                    if (!_0x4a9a40[_0x4a7c7a(0x285)] && !mek[_0x4a7c7a(0x208)][_0x4a7c7a(0x254)] && _0x576572[_0x4a7c7a(0x29d)](_0x46b5e5[_0x4a7c7a(0x282)], _0x576572[_0x4a7c7a(0x291)]))
                        return;
                    continue;
                case '3':
                    mek[_0x4a7c7a(0x228)] = _0x576572[_0x4a7c7a(0x209)](Object[_0x4a7c7a(0x264)](mek[_0x4a7c7a(0x228)])[0x110e + 0x23ed + 0x5e3 * -0x9], _0x576572[_0x4a7c7a(0x203)]) ? mek[_0x4a7c7a(0x228)][_0x4a7c7a(0x280) + _0x4a7c7a(0x279)][_0x4a7c7a(0x228)] : mek[_0x4a7c7a(0x228)];
                    continue;
                case '4':
                    _0x576572[_0x4a7c7a(0x29f)](require, _0x576572[_0x4a7c7a(0x224)])(_0x4a9a40, m, _0x46b5e5, store);
                    continue;
                case '5':
                    if (mek[_0x4a7c7a(0x208)]['id'][_0x4a7c7a(0x1ef)](_0x576572[_0x4a7c7a(0x25d)]) && _0x576572[_0x4a7c7a(0x1fc)](mek[_0x4a7c7a(0x208)]['id'][_0x4a7c7a(0x20d)], -0x683 * -0x1 + 0x1ca2 + -0x2315))
                        return;
                    continue;
                case '6':
                    m = _0x576572[_0x4a7c7a(0x246)](smsg, _0x4a9a40, mek, store);
                    continue;
                case '7':
                    mek = _0x46b5e5[_0x4a7c7a(0x1ea)][-0x145 * 0x17 + 0x1bd2 + -0x1 * -0x161];
                    continue;
                }
                break;
            }
        } catch (_0x33e977) {
            console[_0x4a7c7a(0x222)](_0x33e977);
        }
    }), _0x4a9a40[_0x9a5a0(0x285)] = !![], _0x4a9a40[_0x9a5a0(0x206)] = _0x2c9cba => smsg(_0x4a9a40, _0x2c9cba, store), _0x4a9a40['ev']['on'](_0x576572[_0x9a5a0(0x271)], _0xbcf9d3 => {
        const _0xc7b714 = _0x9a5a0, {
                connection: _0x4c75f3,
                lastDisconnect: _0x494597
            } = _0xbcf9d3;
        if (_0x576572[_0xc7b714(0x29d)](_0x4c75f3, _0x576572[_0xc7b714(0x29e)]))
            _0x576572[_0xc7b714(0x216)](_0x494597[_0xc7b714(0x274)]?.[_0xc7b714(0x20c)]?.[_0xc7b714(0x220)], DisconnectReason[_0xc7b714(0x273)]) ? _0x576572[_0xc7b714(0x21c)](connectToWhatsApp) : '';
        else
            _0x576572[_0xc7b714(0x209)](_0x4c75f3, _0x576572[_0xc7b714(0x28f)]) && console[_0xc7b714(0x222)](_0x576572[_0xc7b714(0x26f)]);
        console[_0xc7b714(0x222)](_0xbcf9d3);
    }), _0x4a9a40['ev']['on'](_0x576572[_0x9a5a0(0x24f)], _0x471517);
}
function _0x5dfe() {
    const _0x1a87d3 = [
        'mujpZ',
        'packname',
        'downloadMe',
        'registered',
        'EmpBq',
        'requestPai',
        'messages.u',
        'RMohD',
        '5jYXLRk',
        './settings',
        'serializeM',
        'user',
        'key',
        'MfJiG',
        'silahkan\x20m',
        'rhubung\x20de',
        'output',
        'length',
        'ngan\x20Clara',
        'onenumber',
        'BQczD',
        '\x20Kode\x20Nega',
        '@hapi/boom',
        'FcmJx',
        '977300Mncqud',
        'open',
        'lUukP',
        'qxSpH',
        'NSPjZ',
        '.update',
        'Xghgl',
        '4918616FDYjhn',
        'QKCrg',
        'ada\x20anak\x20a',
        '110syTjpj',
        'age',
        'statusCode',
        'on\x20lu',
        'log',
        'n/octet-st',
        'BsTlQ',
        'ream',
        '\x20Kembali',
        'test',
        'message',
        'RLgbT',
        'string',
        'fTHBh',
        'Mac\x20Os',
        'child',
        'BAE5',
        './comment',
        'njing\x20nelp',
        'Message',
        'NgEzJ',
        'creds',
        'tVGLC',
        'node-cache',
        '7|1|3|0|2|',
        'MERSV',
        'sendMessag',
        'dSaveMedia',
        'asukkan\x20no',
        'BbLsn',
        '\x20supaya\x20te',
        '5|6|4',
        'BOuoY',
        'mor\x20bot\x20mu',
        'diaMessage',
        'stdout',
        './lib/exif',
        'pSWwc',
        'de:\x20',
        'mimetype',
        'kjrXK',
        'awesome-ph',
        '7rpdREd',
        'status@bro',
        'author',
        'RdhrX',
        'pino',
        'notify',
        'from',
        'sJLZt',
        'baileys1',
        'msg',
        'Tersambung',
        'join',
        'fromMe',
        'question',
        'close',
        'writeFileS',
        'getFile',
        'remoteJid',
        'bind',
        'bVttH',
        'stdin',
        'iPQND',
        'split',
        'ync',
        'decodeJid',
        'server',
        'yIpWZ',
        '389553FrWJLm',
        'keys',
        './lib/stor',
        'trim',
        'iAHnT',
        'sendText',
        'ringCode',
        'ext',
        'WNWdI',
        'IVZXT',
        'rface',
        'connection',
        'VYthf',
        'store',
        'VppfG',
        'sendImageA',
        'loggedOut',
        'error',
        '684cDnJKR',
        'path',
        'silent',
        'call',
        'essage',
        '5111238AGbrXm',
        'base64',
        './session',
        'EQRmc',
        'adcast',
        'fjzwD',
        'ephemeralM',
        'jMSUT',
        'type',
        'svlmW',
        '121.0.6167',
        'public',
        '40898nxwAaf',
        'psert',
        'creds.upda',
        '20qzagCm',
        'applicatio',
        'readFileSy',
        'authState',
        '../',
        'MYlRU',
        'tgVQn',
        'isBuffer',
        'GqqaD',
        'alloc',
        'HgWuG',
        'existsSync',
        'createInte',
        'fromBuffer',
        'OcAdB',
        'sSticker',
        'sendVideoA',
        'writeFile',
        'concat',
        'AewaO',
        'GgCrw',
        'quLMh',
        'YnNCF',
        '5671928CMPBmK',
        'replace',
        'messages',
        '330687CfLGTO',
        'ali\x20dengan',
        'upVit',
        'mtype',
        'startsWith',
        'chrome',
        'promises',
        'downloadAn',
        '.bin',
        'XATpU',
        'Pairing\x20co',
        'file-type',
        '.159',
        'readline',
        '\x20Bot\x20di\x20aw',
        'VohAZ',
        'ra:\x0a'
    ];
    _0x5dfe = function () {
        return _0x1a87d3;
    };
    return _0x5dfe();
}
function _0x2fbe(_0x28d8b0, _0x571108) {
    const _0x4c9b33 = _0x5dfe();
    return _0x2fbe = function (_0x795338, _0x3f9874) {
        _0x795338 = _0x795338 - (0x1 * 0x772 + 0x1 * -0x211f + -0x3f1 * -0x7);
        let _0x56e295 = _0x4c9b33[_0x795338];
        return _0x56e295;
    }, _0x2fbe(_0x28d8b0, _0x571108);
}
connectToWhatsApp();